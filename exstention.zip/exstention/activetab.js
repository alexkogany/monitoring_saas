$(function(){
    $(document).ready(function(){
        console.log("active tab");
    })
});