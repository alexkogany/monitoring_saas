$(function(){
    $(document).ready(function(){
        //alert("replace tab");
    })
});